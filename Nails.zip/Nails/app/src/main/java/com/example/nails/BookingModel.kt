package com.example.nails

 class BookingModel {



        var username :String = ""
        var password :String = ""
        var email:String = ""
        var phone:String = ""
        var date:String = ""
        var time:String = ""








}